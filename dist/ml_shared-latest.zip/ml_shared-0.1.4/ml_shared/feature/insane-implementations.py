import numpy as np
import category_encoders as ce
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split

N = 1000

np.random.seed(42)
X, y = make_classification(n_samples=N, random_state=42)
X = X.round(1).astype(str)
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=.2, random_state=42)


counter = ce.CountEncoder(return_df=False)
type(counter.fit_transform(X_train))
type(counter.transform(X_test))

targetter = ce.TargetEncoder(return_df=False)
type(targetter.fit_transform(X_train, y_train))
type(counter.transform(X_test))

binarizer = ce.BinaryEncoder(return_df=False)
binarizer.fit_transform(X_train)

onehotter = ce.OneHotEncoder(return_df=False)
type(onehotter.fit_transform(X_train))
type(onehotter.transform(X_test))