#!/usr/bin/env python3
# -*- coding: utf-8 -*-
from sklearn.preprocessing import LabelEncoder, StandardScaler, MinMaxScaler, LabelEncoder, OneHotEncoder
from sklearn.compose import ColumnTransformer, TransformedTargetRegressor
from sklearn.pipeline import Pipeline

import pandas as pd
import numpy as np
from scipy.sparse import coo_matrix, csr_matrix, lil_matrix, csc_matrix
import category_encoders as ce

from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split

from sklearn.linear_model import LogisticRegression

N = 1000000

np.random.seed(42)
d = pd.DataFrame({'cat': np.random.choice(
    [str(x) for x in list(range(1000))], size=N)})
X, y = make_classification(n_samples=N, random_state=42)
X = np.hstack((X, d.cat.values.reshape(-1, 1)))
X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=.2, random_state=42)
X_test[2, 20] = "O"

# category encoder のキライなところー
# その1: 勝手に型を変えるからまともに機能しない. あほしね
# その2: return_df=False しても return_dfする. あほしね
# その3: min_group... 明示的に設定しないとエラー, handle_unknownもデフォルトが NaN. センスがない
counter = ce.CountEncoder(return_df=False, handle_missing='count', normalize=True, min_group_size=.1)
targetter = ce.TargetEncoder(return_df=False)
# その4: missing/unknown を置換するという発想がない. 実用性を考慮してない. あほしね
# その5: ふつうに使おうとしただけでもエラーとかありえない
onehotter = ce.OneHotEncoder(return_df=False, handle_missing=0, handle_unknown=0)
onehotter_native = OneHotEncoder(handle_unknown='ignore')
standardizer = StandardScaler()
preprocessor = ColumnTransformer([
    ('standardize', standardizer, slice(0, 20)),
    ('encoder', onehotter, [20])
])

counter.fit(X_train)
counter.transform(X_train)
counter.transform(X_test)

preprocessor.fit(X_train, y_train)
preprocessor.transform(X_train)[2, :]
preprocessor.transform(X_test)[2, :]

est = Pipeline([
    ('preprocessor', preprocessor),
    ('learner', LogisticRegression())
])

est.fit(X_train, y_train)
est.predict_proba(X_train)
est.predict_proba(X_test)
